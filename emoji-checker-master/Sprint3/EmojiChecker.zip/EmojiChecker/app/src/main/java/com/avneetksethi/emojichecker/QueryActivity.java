package com.avneetksethi.emojichecker;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class QueryActivity extends AppCompatActivity {
    private TextView textView;
    private SeekBar seekBar;
    private Button submitButton;
    private ImageView image1, image2, image3, image4, image5, image6, image7, image8, image9;
    int[] emojis = {R.drawable.sleepy, R.drawable.angry, R.drawable.nervous, R.drawable.passive, R.drawable.confused,
            R.drawable.neutral, R.drawable.content, R.drawable.giggly, R.drawable.happy};

    String keyword = "";
    int min = 1, max = 9, current = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_query);
        image1 = (ImageView) findViewById(R.id.sleepyImageView);
        image2 = (ImageView) findViewById(R.id.angryImageView);
        image3 = (ImageView) findViewById(R.id.nervousImageView);
        image4 = (ImageView) findViewById(R.id.passiveImageView);
        image5 = (ImageView) findViewById(R.id.confusedImageView);
        image6 = (ImageView) findViewById(R.id.neutralImageView);
        image7 = (ImageView) findViewById(R.id.contentImageView);
        image8 = (ImageView) findViewById(R.id.gigglyImageView);
        image9 = (ImageView) findViewById(R.id.happyImageView);


        submitButton = (Button) findViewById(R.id.submitButton);
        textView = (TextView) findViewById(R.id.textView);
        seekBar = (SeekBar) findViewById(R.id.seekBar);

        seekBar.setMax(max - min);
        seekBar.setProgress(current - min);
        textView.setText("Sleepy");


        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                current = progress + min;
                sliderEnabled(current);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Send selected emoji from slider to the server and display the correct screen
                sendEmoji();
            }
        });

    }

    public String sliderEnabled(int current) {
        //Map the value of the slider to each emoji
        switch (current) {
            case 1:
                textView.setText("Sleepy");
                image1.setImageResource(emojis[0]);
                keyword = "Sleepy";
                break;
            case 2:
                textView.setText("Angry");
                image2.setImageResource(emojis[1]);
                keyword = "Angry";
                break;
            case 3:
                textView.setText("Nervous");
                image3.setImageResource(emojis[2]);
                keyword = "Nervous";
                break;
            case 4:
                textView.setText("Passive-Aggressive");
                image4.setImageResource(emojis[3]);
                keyword = "Passive-Aggressive";
                break;
            case 5:
                textView.setText("Confused");
                image5.setImageResource(emojis[4]);
                keyword = "Confused";
                break;
            case 6:
                textView.setText("Neutral");
                image6.setImageResource(emojis[5]);
                keyword = "Neutral";
                break;
            case 7:
                textView.setText("Content");
                image7.setImageResource(emojis[6]);
                keyword = "Content";
                break;
            case 8:
                textView.setText("Giggly");
                image8.setImageResource(emojis[7]);
                keyword = "Giggly";
                break;
            case 9:
                textView.setText("Happy");
                image9.setImageResource(emojis[8]);
                keyword = "Happy";
                break;

        }
        return keyword; //Return the string keyword that matches emoji selected by user
    }

    /*public String getToken(){

    }*/

    public void sendEmoji() {
        final RequestQueue queue = Volley.newRequestQueue(QueryActivity.this);
        String URL = "http://www.emoji-survey.me/responses/";
        StringRequest sr = new  StringRequest(Request.Method.POST, "http://www.emoji-survey.me/responses/", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //This code is executed if the server responds, whether or not the response contains data.
                //The String 'response' contains the server's response.
                //textView.setText(response.toString());
                queue.stop();
                openConfirmationScreen(); //Launch confirmation screen
            }}, new Response.ErrorListener() { //Create an error listener to handle errors appropriately.
            @Override
            public void onErrorResponse(VolleyError error) {
                //This code is executed if there is an error.
                //textView.setText("Error Sending Response");
                error.printStackTrace();
                queue.stop();
                openErrorScreen(); //Launch error screen
            }
        }) {
            public Map getHeaders() throws AuthFailureError {
                HashMap headers = new HashMap();
                headers.put("Authorization", "Token 53d63c65588174ca2800e05fb81e6170896378f5");
                return headers;

            }
            public Map<String, String> getParams() {
                //Add the data to send to the server.
                Map<String, String> MyData = new HashMap<String, String>();
                MyData.put("emoji", keyword);
                return MyData;
            }
        };
        queue.add(sr);
    }

    public void openConfirmationScreen() {
        //Used to launches the confirmation screen
        Intent intent = new Intent(this, QueryConfirmation.class);
        startActivity(intent);
    }

    public void openErrorScreen() {
        //Used to launches the error screen
        Intent intent = new Intent(this, QueryError.class);
        startActivity(intent);
    }

}

