package com.avneetksethi.emojichecker;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class RegisterRequest extends StringRequest {

    private static final String RegisterRequestURL = "http://www.emoji-survey.me/auth/users/create";
    private Map<String, String> params;

   public RegisterRequest(String firstName, String lastName, String email, String birthDate, String phoneNumber, String username, String password, Response.Listener<String> listener) {
        super(Request.Method.POST, RegisterRequestURL, listener, null);
        params = new HashMap<>();
        params.put("first name", firstName);
        params.put("last name", lastName);
        params.put("email address", email);
        params.put("birth date", birthDate);
        params.put("phone number", phoneNumber);
        params.put("username", username);
        params.put("password", password);

   }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}

